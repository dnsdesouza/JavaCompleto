package br.com.cod3r.exercicios_springBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExerciciosSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
