package br.com.cod3r.SpringBootCod3r;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootCod3rApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootCod3rApplication.class, args);
	}

}
